#pragma once
#include <Windows.h>

VOID removeHooks(HMODULE hmodule);