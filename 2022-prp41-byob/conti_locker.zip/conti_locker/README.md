### Conti Locker Source code

This is the source code of the conti locker which was leacked by a conti affiliate. 
[blog post](https://medium.com/@whickey000/how-i-cracked-conti-ransomware-groups-leaked-source-code-zip-file-e15d54663a8)
